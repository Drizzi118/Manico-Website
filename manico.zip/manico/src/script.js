// Select the button
const clickBtn = document.getElementById("clickBtn");

// Redirect to your Wix site on click
clickBtn.addEventListener("click", () => {
  window.location.href = "https://tigsmort.wixsite.com/my-site";
});
